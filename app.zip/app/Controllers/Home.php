<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index(): string
    {
      $myVar = "Halo dunia";
        return view("welcome",compact("myVar"));
    }
    public function about(): string   
    {
        return view("about");
    }
}
